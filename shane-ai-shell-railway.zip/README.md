# Shane.AI Shell

Browser-based terminal dashboard with a Node/Express backend, public web search, safe public webpage text extraction, and honest deployment-command guardrails.

## Deploy to Railway

1. Create a GitHub repository and upload the contents of this folder.
2. In Railway, create a new project and choose **Deploy from GitHub repo**.
3. Select this repository. Railway detects `railway.json` and the `Dockerfile`.
4. Deploy. Railway provides the public domain under **Settings → Networking → Generate Domain**.
5. Verify `/api/health` reports `ok: true`.

You can also deploy the folder using the Railway CLI from your own terminal after installing and logging into `railway`:
```bash
railway login
railway init
railway up
```

## Commands

- `help`
- `status`
- `web_search <query>` — uses DuckDuckGo's public HTML results; no API key is required, but availability and parsing can change.
- `web_fetch <url>` — extracts readable text from public HTML/text pages. Local/private IPs are blocked, redirects are not followed, and page size/time are limited.
- `deploy_website <url>` and `deploy_app <app_name> <app_path>` — deliberately report that a provider integration is not configured. They do not fake success. To make these deploy commands perform real deployments, integrate an authenticated provider API or a controlled deployment worker and store credentials as server-side environment variables. Do not expose provider tokens to the browser.
- `clear`, `exit`

## Important security note

This is a browser-based command interface, not a general-purpose OS shell. It intentionally does not run arbitrary terminal commands or access files on the user's PC. Do not add arbitrary command execution to a public service without strong authentication, authorization, isolation, audit logs, and resource limits.

## Current limitations

- No Railway account or project credentials are bundled, so this package is Railway-ready but not yet published to your Railway account.
- Search depends on a public HTML endpoint and may be rate-limited.
- Web fetching blocks obvious private network destinations and does not follow redirects. For production-grade SSRF resistance, enforce network egress rules too.
- Deployment provider integration is not yet connected.
