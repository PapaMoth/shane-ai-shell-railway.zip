import express from 'express';
import * as cheerio from 'cheerio';
import dns from 'node:dns/promises';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

function isPrivateIPv4(ip) {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 10 || p[0] === 127 || p[0] === 0 ||
    (p[0] === 169 && p[1] === 254) ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
    p[0] >= 224;
}
function isPrivateIPv6(ip) {
  const s = ip.toLowerCase();
  return s === '::1' || s === '::' || s.startsWith('fc') || s.startsWith('fd') ||
    /^fe[89ab]/.test(s) || s.startsWith('::ffff:127.') || s.startsWith('::ffff:10.');
}
async function validatePublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('Enter a valid URL.'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only http:// and https:// URLs are supported.');
  if (u.username || u.password) throw new Error('URLs containing credentials are not allowed.');
  const host = u.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) {
    throw new Error('Local and private network addresses are blocked.');
  }
  if (net.isIP(host)) {
    if ((net.isIPv4(host) && isPrivateIPv4(host)) || (net.isIPv6(host) && isPrivateIPv6(host))) {
      throw new Error('Local and private network addresses are blocked.');
    }
  } else {
    const records = await dns.lookup(host, { all: true }).catch(() => []);
    if (!records.length) throw new Error('The hostname could not be resolved.');
    for (const r of records) {
      if ((net.isIPv4(r.address) && isPrivateIPv4(r.address)) ||
          (net.isIPv6(r.address) && isPrivateIPv6(r.address))) {
        throw new Error('The hostname resolves to a private address and is blocked.');
      }
    }
  }
  return u;
}
async function safeFetch(raw) {
  const u = await validatePublicUrl(raw);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(u, {
      signal: controller.signal,
      redirect: 'manual',
      headers: { 'user-agent': 'ShaneAI-Shell/1.0 (web fetch)', 'accept': 'text/html,text/plain;q=0.9,*/*;q=0.5' }
    });
    if ([301,302,303,307,308].includes(response.status)) {
      throw new Error('Redirects are not followed for safety. Open the final destination URL directly.');
    }
    if (!response.ok) throw new Error(`The website returned HTTP ${response.status}.`);
    const type = response.headers.get('content-type') || '';
    if (!type.includes('text/html') && !type.includes('text/plain') && !type.includes('application/xhtml+xml')) {
      throw new Error(`Unsupported content type: ${type || 'unknown'}. Only HTML and plain text are extracted.`);
    }
    const declaredLength = Number(response.headers.get('content-length') || 0);
    if (declaredLength > 2_000_000) throw new Error('Page is too large (limit 2 MB).');
    const body = await response.text();
    if (body.length > 2_000_000) throw new Error('Page is too large (limit 2 MB).');
    return { body, url: u.href, contentType: type };
  } finally {
    clearTimeout(timeout);
  }
}

app.get('/api/health', (_req, res) => res.json({
  ok: true,
  app: 'Shane.AI Shell',
  search: 'DuckDuckGo HTML search (no API key required)',
  fetch: 'HTML/plain-text extraction with private-network URL blocking',
  deployment: 'Not configured: deployment commands require a deployment provider integration and credentials.'
}));

app.post('/api/command', async (req, res) => {
  const command = String(req.body?.command || '').trim();
  if (!command || command.length > 2000) {
    return res.status(400).json({ ok: false, error: 'Enter a command (maximum 2,000 characters).' });
  }
  const [name, ...args] = command.split(/\s+/);
  const rest = command.slice(name.length).trim();

  try {
    if (name === 'help') {
      return res.json({ ok: true, title: 'Available commands', output:
`help
web_search <query>
web_fetch <url>
deploy_website <url>
deploy_app <app_name> <app_path>
status
clear
exit

Working now: web_search, web_fetch, status.
Deployment commands are guarded and will not claim success without a configured provider.
The browser shell does not execute arbitrary operating-system commands.` });
    }
    if (name === 'status') {
      return res.json({ ok: true, title: 'System status', output:
`Shane.AI Shell API: online
Web search: DuckDuckGo HTML endpoint (best-effort; subject to network/provider changes)
Web fetch: enabled with URL validation and private-network blocking
Website/app deployment: not configured
Arbitrary OS shell access: intentionally disabled in browser mode` });
    }
    if (name === 'web_search') {
      if (!rest) throw new Error('Usage: web_search <query>');
      const endpoint = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(rest)}`;
      const response = await fetch(endpoint, {
        headers: { 'user-agent': 'Mozilla/5.0 (compatible; ShaneAI-Shell/1.0)', 'accept': 'text/html' },
        signal: AbortSignal.timeout(12000)
      });
      if (!response.ok) throw new Error(`Search provider returned HTTP ${response.status}.`);
      const html = await response.text();
      const $ = cheerio.load(html);
      const results = [];
      $('.result').each((_i, el) => {
        const titleEl = $(el).find('.result__title a');
        const snippetEl = $(el).find('.result__snippet');
        const title = titleEl.text().trim();
        const url = titleEl.attr('href') || '';
        const snippet = snippetEl.text().trim();
        if (title && url && results.length < 8) results.push({ title, url, snippet });
      });
      if (!results.length) {
        return res.json({ ok: true, title: `Search: ${rest}`, output:
          'The search provider returned no parseable results. It may be rate-limiting requests or changing its page format. Try again later.' });
      }
      return res.json({ ok: true, title: `Search: ${rest}`, results,
        output: results.map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}\n   ${r.snippet}`).join('\n\n') });
    }
    if (name === 'web_fetch') {
      if (!rest) throw new Error('Usage: web_fetch <url>');
      const fetched = await safeFetch(rest);
      const $ = cheerio.load(fetched.body);
      $('script, style, nav, footer, header, noscript, svg, form').remove();
      const title = $('title').first().text().trim() || fetched.url;
      const text = $('body').text().replace(/\s+/g, ' ').trim().slice(0, 12000);
      return res.json({ ok: true, title: `Fetched: ${title}`,
        output: `URL: ${fetched.url}\nContent type: ${fetched.contentType}\n\n${text || '(No readable text was found.)'}` });
    }
    if (name === 'deploy_website') {
      if (!rest) throw new Error('Usage: deploy_website <url>');
      await validatePublicUrl(rest);
      return res.json({ ok: false, title: 'Deployment not configured',
        error: 'URL validated, but no website deployment provider is connected. Configure a provider integration and credentials before this command can deploy anything.',
        output: 'No deployment was performed. This shell does not pretend a deploy succeeded.' });
    }
    if (name === 'deploy_app') {
      if (args.length < 2) throw new Error('Usage: deploy_app <app_name> <app_path>');
      return res.json({ ok: false, title: 'Deployment not configured',
        error: 'No deployment provider is connected. The browser service cannot access an arbitrary path on your computer. To deploy, connect a supported provider and supply a repository or uploaded project.',
        output: 'No deployment was performed. Configure provider credentials as server-side environment variables, never in browser code.' });
    }
    if (name === 'clear') return res.json({ ok: true, clear: true, output: '' });
    if (name === 'exit') return res.json({ ok: true, output: 'Browser session ended. You can start a new session by running another command.' });
    return res.status(400).json({ ok: false, error: `Unknown command: ${name}. Run help to see supported commands.` });
  } catch (error) {
    const message = error?.name === 'TimeoutError' || error?.name === 'AbortError'
      ? 'The request timed out. Try again.'
      : (error?.message || 'Unexpected server error.');
    return res.status(400).json({ ok: false, error: message });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Shane.AI Shell listening on port ${PORT}`);
});
