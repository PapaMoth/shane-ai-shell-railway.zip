const terminal = document.getElementById('terminal');
const form = document.getElementById('commandForm');
const input = document.getElementById('commandInput');
const apiStatus = document.getElementById('apiStatus');
const sideStatus = document.getElementById('sideStatus');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function appendCommand(command) {
  const el = document.createElement('div');
  el.className = 'output-block';
  el.innerHTML = `<div class="output-command"><span class="prompt">shane@workspace</span><span class="muted">:~$</span> ${escapeHtml(command)}</div>`;
  terminal.appendChild(el);
  return el;
}
function appendResult(parent, result) {
  if (result.clear) { terminal.innerHTML = ''; return; }
  if (result.title) {
    const title = document.createElement('div');
    title.className = 'output-title';
    title.textContent = result.title;
    parent.appendChild(title);
  }
  const content = document.createElement('div');
  content.className = result.ok === false ? 'output-error' : 'output-text';
  content.textContent = result.error || result.output || 'Command completed with no output.';
  parent.appendChild(content);
  if (Array.isArray(result.results) && result.results.length) {
    const list = document.createElement('div');
    list.style.marginTop = '10px';
    result.results.forEach((item, i) => {
      const row = document.createElement('div');
      row.style.marginBottom = '12px';
      const link = document.createElement('a');
      link.className = 'result-link';
      link.href = item.url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = `${i + 1}. ${item.title}`;
      row.appendChild(link);
      const snippet = document.createElement('div');
      snippet.className = 'output-text';
      snippet.textContent = item.snippet || item.url;
      row.appendChild(snippet);
      list.appendChild(row);
    });
    parent.appendChild(list);
  }
  terminal.scrollTop = terminal.scrollHeight;
}
async function runCommand(command) {
  const trimmed = command.trim();
  if (!trimmed) return;
  const block = appendCommand(trimmed);
  input.value = '';
  const pending = document.createElement('div');
  pending.className = 'output-text';
  pending.textContent = 'Running…';
  block.appendChild(pending);
  try {
    const response = await fetch('/api/command', {
      method: 'POST',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({command: trimmed})
    });
    const result = await response.json();
    pending.remove();
    appendResult(block, result);
  } catch {
    pending.remove();
    appendResult(block, {ok:false, error:'Could not reach the shell API. Check the server status and try again.'});
  }
}
form.addEventListener('submit', event => {
  event.preventDefault();
  runCommand(input.value);
});
document.querySelectorAll('[data-command]').forEach(button => {
  button.addEventListener('click', () => {
    const cmd = button.dataset.command;
    input.value = cmd;
    input.focus();
    if (cmd === 'help' || cmd === 'status') runCommand(cmd);
  });
});
document.getElementById('clearBtn').addEventListener('click', () => {
  terminal.innerHTML = '<div class="output-text">Output cleared. Run <b>help</b> to see commands.</div>';
});
document.getElementById('commandsNav').addEventListener('click', () => runCommand('help'));
document.getElementById('terminalNav').addEventListener('click', () => input.focus());
fetch('/api/health').then(r => r.json()).then(data => {
  apiStatus.textContent = data.ok ? 'Online' : 'Unavailable';
  apiStatus.previousElementSibling.style.background = data.ok ? '#47d7a0' : '#ed6a69';
  sideStatus.textContent = data.ok ? 'Shell API connected' : 'Shell API unavailable';
}).catch(() => {
  apiStatus.textContent = 'Unavailable';
  sideStatus.textContent = 'Shell API unavailable';
});
